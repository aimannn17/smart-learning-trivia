# Smart Learning & Trivia Assessment Hub

SPG0562 Mini Project (Jul 2026). A 3-activity Android app written in Java.

## Open and run
1. Android Studio > File > Open > select this `SmartTriviaHub` folder.
2. Let Gradle sync (it downloads Volley the first time).
3. Run on an emulator or phone **with internet**.

## Where each rubric item lives

| Rubric item | Where |
|---|---|
| 3 activities, explicit Intents + Bundles | `MainActivity` -> `QuizActivity` -> `ResultActivity` (`AppKeys` holds the Bundle keys) |
| All 7 lifecycle callbacks with `Log.d()` | Every activity: onCreate, onStart, onResume, onPause, onStop, onRestart, onDestroy. Filter Logcat by `MainActivity`, `QuizActivity` or `ResultActivity` |
| Data Binding instead of findViewById | `buildFeatures { dataBinding = true }`; every layout uses `<layout>` and `<data>` variables; activities use `DataBindingUtil.setContentView` |
| Volley GET + JSON parsing | `QuizActivity.fetchQuestions()` and `handleResponse()` (JSONObject -> "results" JSONArray -> each JSONObject) |
| INTERNET permission | `AndroidManifest.xml` |
| Validation | `MainActivity.validateForm()`: empty and invalid name, student ID, email, programme |
| Choice buttons, ImageView feedback, popups | `QuizActivity.onOptionSelected()` / `applyAnsweredState()`: ImageView swaps idle/correct/wrong, Snackbar after every answer, Toast when questions load, AlertDialogs for network errors and quitting |
| Score and percentage | `ResultActivity.calculatePercentage()` and `gradeFor()` (unit tested in `ScoreCalculationTest`) |
| ScrollView breakdown | `activity_result.xml` NestedScrollView + `item_result.xml` rows |
| ConstraintLayout, centred in portrait and landscape | All screens: content constrained to the centre with a max width; quiz keeps its progress on rotation (`onSaveInstanceState`) |
| No hardcoded text or colours | Everything in `strings.xml`, `colors.xml`, `dimens.xml`, `styles.xml` |

## Web API
Open Trivia Database: `https://opentdb.com/api.php?amount=10&type=multiple`.
The API allows one request every 5 seconds per IP; if you see "Too many requests", wait and tap Retry.
