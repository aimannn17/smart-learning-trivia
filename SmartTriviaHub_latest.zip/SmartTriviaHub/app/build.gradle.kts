plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.smarttriviahub"
    compileSdk {
        version = release(37)
    }

    defaultConfig {
        applicationId = "com.example.smarttriviahub"
        minSdk = 30
        targetSdk = 37
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    // Data Binding generates ActivityMainBinding, ActivityQuizBinding, ActivityResultBinding
    // and ItemResultBinding, so no findViewById() is needed anywhere.
    buildFeatures {
        dataBinding = true
    }

    buildTypes {
        release {
            optimization {
                enable = false
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    implementation(libs.activity.ktx)
    implementation(libs.appcompat)
    implementation(libs.constraintlayout)
    implementation(libs.material)
    implementation(libs.volley)
    testImplementation(libs.junit)
    androidTestImplementation(libs.espresso.core)
    androidTestImplementation(libs.ext.junit)
}
