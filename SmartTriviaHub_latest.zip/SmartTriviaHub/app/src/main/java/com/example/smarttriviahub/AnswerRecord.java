package com.example.smarttriviahub;

import java.io.Serializable;

/**
 * What the student answered for one question. A list of these is sent to
 * ResultActivity to build the itemised breakdown.
 */
public class AnswerRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    private final int number;
    private final String questionText;
    private final String userAnswer;
    private final String correctAnswer;
    private final boolean correct;

    public AnswerRecord(int number, String questionText, String userAnswer,
                        String correctAnswer, boolean correct) {
        this.number = number;
        this.questionText = questionText;
        this.userAnswer = userAnswer;
        this.correctAnswer = correctAnswer;
        this.correct = correct;
    }

    public int getNumber() {
        return number;
    }

    public String getQuestionText() {
        return questionText;
    }

    public String getUserAnswer() {
        return userAnswer;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }

    public boolean isCorrect() {
        return correct;
    }
}
