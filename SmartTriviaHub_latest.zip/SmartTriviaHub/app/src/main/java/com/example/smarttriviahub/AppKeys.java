package com.example.smarttriviahub;

/**
 * Keys for the Bundle payloads passed between activities with explicit Intents.
 */
public final class AppKeys {

    public static final String KEY_NAME = "key_student_name";
    public static final String KEY_STUDENT_ID = "key_student_id";
    public static final String KEY_EMAIL = "key_student_email";
    public static final String KEY_PROGRAMME = "key_student_programme";
    public static final String KEY_SCORE = "key_score";
    public static final String KEY_TOTAL = "key_total";
    public static final String KEY_RECORDS = "key_answer_records";

    private AppKeys() {
    }
}
