package com.example.smarttriviahub;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.widget.Toast;

import java.util.Locale;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import com.example.smarttriviahub.databinding.ActivityMainBinding;
import com.google.android.material.textfield.TextInputEditText;

/**
 * Activity 1: User Registration & Entrance.
 * Collects and validates the student's details, then opens QuizActivity
 * with an explicit Intent carrying a Bundle.
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    /** Letters (any language), spaces and . ' @ / - , at least 3 characters. */
    private static final String NAME_PATTERN = "^[\\p{L} .'@/-]{3,}$";
    /** 6 to 12 letters or digits. */
    private static final String STUDENT_ID_PATTERN = "^[A-Za-z0-9]{6,12}$";

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate() called: registration screen created");

        // Data Binding replaces setContentView + findViewById
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main);
        binding.setProgrammeError(null);

        binding.btnStart.setOnClickListener(v -> startAssessment());
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "onStart() called: registration screen is visible");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume() called: user can now interact with the form");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause() called: registration screen losing focus");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop() called: registration screen no longer visible");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG, "onRestart() called: returning to registration screen");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy() called: registration screen destroyed");
    }

    /** Called when ResultActivity sends the user back here to restart as a new student. */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Log.d(TAG, "onNewIntent() called: clearing the form for a new student");
        setIntent(intent);
        clearForm();
    }

    private void startAssessment() {
        if (!validateForm()) {
            Toast.makeText(this, R.string.toast_fix_errors, Toast.LENGTH_SHORT).show();
            Log.d(TAG, "Validation failed");
            return;
        }

        String name = textOf(binding.etName);
        String studentId = textOf(binding.etStudentId).toUpperCase(Locale.ROOT);
        String email = textOf(binding.etEmail);
        String programme = binding.spProgramme.getSelectedItem().toString();

        // Pack the student's details into a Bundle and send them with an explicit Intent
        Bundle bundle = new Bundle();
        bundle.putString(AppKeys.KEY_NAME, name);
        bundle.putString(AppKeys.KEY_STUDENT_ID, studentId);
        bundle.putString(AppKeys.KEY_EMAIL, email);
        bundle.putString(AppKeys.KEY_PROGRAMME, programme);

        Intent intent = new Intent(MainActivity.this, QuizActivity.class);
        intent.putExtras(bundle);

        Log.d(TAG, "Starting QuizActivity for " + name + " (" + studentId + ")");
        Toast.makeText(this, getString(R.string.toast_welcome, name), Toast.LENGTH_SHORT).show();
        startActivity(intent);
    }

    /** Checks every field and shows an error under each one that is empty or invalid. */
    private boolean validateForm() {
        boolean valid = true;

        String name = textOf(binding.etName);
        if (name.isEmpty()) {
            binding.tilName.setError(getString(R.string.error_name_required));
            valid = false;
        } else if (!name.matches(NAME_PATTERN)) {
            binding.tilName.setError(getString(R.string.error_name_invalid));
            valid = false;
        } else {
            binding.tilName.setError(null);
        }

        String studentId = textOf(binding.etStudentId);
        if (studentId.isEmpty()) {
            binding.tilStudentId.setError(getString(R.string.error_id_required));
            valid = false;
        } else if (!studentId.matches(STUDENT_ID_PATTERN)) {
            binding.tilStudentId.setError(getString(R.string.error_id_invalid));
            valid = false;
        } else {
            binding.tilStudentId.setError(null);
        }

        String email = textOf(binding.etEmail);
        if (email.isEmpty()) {
            binding.tilEmail.setError(getString(R.string.error_email_required));
            valid = false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.tilEmail.setError(getString(R.string.error_email_invalid));
            valid = false;
        } else {
            binding.tilEmail.setError(null);
        }

        // Position 0 is the "Select your programme" hint
        if (binding.spProgramme.getSelectedItemPosition() == 0) {
            binding.setProgrammeError(getString(R.string.error_programme_required));
            valid = false;
        } else {
            binding.setProgrammeError(null);
        }

        return valid;
    }

    private void clearForm() {
        binding.etName.setText(null);
        binding.etStudentId.setText(null);
        binding.etEmail.setText(null);
        binding.spProgramme.setSelection(0);
        binding.tilName.setError(null);
        binding.tilStudentId.setError(null);
        binding.tilEmail.setError(null);
        binding.setProgrammeError(null);
        binding.etName.requestFocus();
    }

    private static String textOf(TextInputEditText field) {
        return field.getText() == null ? "" : field.getText().toString().trim();
    }
}
