package com.example.smarttriviahub;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Model for one trivia question parsed from the Open Trivia DB JSON.
 * The four options are shuffled once, when the question is created.
 */
public class Question implements Serializable {

    private static final long serialVersionUID = 1L;

    private final String text;
    private final String category;
    private final String difficulty;
    private final String correctAnswer;
    private final ArrayList<String> options;

    public Question(String text, String category, String difficulty,
                    String correctAnswer, List<String> incorrectAnswers) {
        this.text = text;
        this.category = category;
        this.difficulty = difficulty;
        this.correctAnswer = correctAnswer;
        this.options = new ArrayList<>();
        this.options.add(correctAnswer);
        this.options.addAll(incorrectAnswers);
        Collections.shuffle(this.options);
    }

    public String getText() {
        return text;
    }

    public String getCategory() {
        return category;
    }

    public String getDifficulty() {
        return difficulty;
    }

    /** "medium" becomes "Medium" for display. */
    public String getDifficultyLabel() {
        if (difficulty == null || difficulty.isEmpty()) {
            return "";
        }
        return difficulty.substring(0, 1).toUpperCase(Locale.ROOT) + difficulty.substring(1);
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }

    public List<String> getOptions() {
        return options;
    }

    public boolean isCorrect(String answer) {
        return correctAnswer.equals(answer);
    }
}
