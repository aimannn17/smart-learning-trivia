package com.example.smarttriviahub;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.os.BundleCompat;
import androidx.databinding.DataBindingUtil;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.smarttriviahub.databinding.ActivityQuizBinding;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Activity 2: Web-Connected Trivia Quiz Hub.
 * Downloads 10 questions with Volley, shows them through Data Binding,
 * checks each answer, updates the feedback image and shows a Snackbar.
 */
public class QuizActivity extends AppCompatActivity {

    private static final String TAG = "QuizActivity";
    private static final String REQUEST_TAG = "trivia_request";
    private static final int TIMEOUT_MS = 10000;

    // Keys used to keep the quiz when the screen rotates
    private static final String STATE_QUESTIONS = "state_questions";
    private static final String STATE_RECORDS = "state_records";
    private static final String STATE_INDEX = "state_index";
    private static final String STATE_SCORE = "state_score";
    private static final String STATE_ANSWERED = "state_answered";
    private static final String STATE_SELECTED = "state_selected";

    private ActivityQuizBinding binding;
    private RequestQueue requestQueue;
    private MaterialButton[] optionButtons;
    private AlertDialog activeDialog;
    private Bundle studentBundle;

    private ArrayList<Question> questions = new ArrayList<>();
    private ArrayList<AnswerRecord> records = new ArrayList<>();
    private int currentIndex = 0;
    private int score = 0;
    private boolean answered = false;
    private int selectedIndex = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate() called: quiz screen created");

        binding = DataBindingUtil.setContentView(this, R.layout.activity_quiz);

        // Read the student's details sent from MainActivity
        studentBundle = getIntent().getExtras();
        if (studentBundle == null) {
            Log.d(TAG, "No student details received, closing quiz");
            finish();
            return;
        }
        binding.setStudentName(studentBundle.getString(AppKeys.KEY_NAME));

        optionButtons = new MaterialButton[]{
                binding.btnOption1, binding.btnOption2, binding.btnOption3, binding.btnOption4
        };
        for (int i = 0; i < optionButtons.length; i++) {
            final int choice = i;
            optionButtons[i].setOnClickListener(v -> onOptionSelected(choice));
        }
        binding.btnNext.setOnClickListener(v -> goToNextQuestion());

        // Ask before leaving in the middle of a quiz
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                showQuitDialog();
            }
        });

        requestQueue = Volley.newRequestQueue(getApplicationContext());

        if (savedInstanceState != null && restoreState(savedInstanceState)) {
            Log.d(TAG, "Quiz restored after configuration change");
            showQuestion();
        } else {
            fetchQuestions();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "onStart() called: quiz screen is visible");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume() called: user can answer questions");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause() called: quiz screen losing focus");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop() called: quiz screen no longer visible");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG, "onRestart() called: returning to the quiz");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy() called: cancelling pending requests");
        if (requestQueue != null) {
            requestQueue.cancelAll(REQUEST_TAG);
        }
        if (activeDialog != null && activeDialog.isShowing()) {
            activeDialog.dismiss();
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.d(TAG, "onSaveInstanceState() called: saving quiz progress");
        outState.putSerializable(STATE_QUESTIONS, questions);
        outState.putSerializable(STATE_RECORDS, records);
        outState.putInt(STATE_INDEX, currentIndex);
        outState.putInt(STATE_SCORE, score);
        outState.putBoolean(STATE_ANSWERED, answered);
        outState.putInt(STATE_SELECTED, selectedIndex);
    }

    // ---------------------------------------------------------------------
    // Networking (Volley)
    // ---------------------------------------------------------------------

    /** Sends a GET request to the Open Trivia DB API for 10 multiple-choice questions. */
    private void fetchQuestions() {
        binding.setLoading(true);
        String url = getString(R.string.api_url);
        Log.d(TAG, "Sending Volley GET request: " + url);

        JsonObjectRequest request = new JsonObjectRequest(
                Request.Method.GET,
                url,
                (JSONObject) null,
                this::handleResponse,
                this::handleError);
        request.setRetryPolicy(new DefaultRetryPolicy(
                TIMEOUT_MS, 1, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        request.setTag(REQUEST_TAG);
        requestQueue.add(request);
    }

    /** Parses the JSONObject, its "results" JSONArray and each question JSONObject. */
    private void handleResponse(JSONObject response) {
        Log.d(TAG, "Volley response received");
        try {
            int responseCode = response.getInt("response_code");
            if (responseCode == 5) {
                showErrorDialog(getString(R.string.error_rate_limit));
                return;
            }
            if (responseCode != 0) {
                showErrorDialog(getString(R.string.error_api_code, responseCode));
                return;
            }

            JSONArray results = response.getJSONArray("results");
            ArrayList<Question> parsed = new ArrayList<>();
            for (int i = 0; i < results.length(); i++) {
                JSONObject item = results.getJSONObject(i);

                JSONArray wrongJson = item.getJSONArray("incorrect_answers");
                List<String> wrongAnswers = new ArrayList<>();
                for (int j = 0; j < wrongJson.length(); j++) {
                    wrongAnswers.add(decode(wrongJson.getString(j)));
                }

                parsed.add(new Question(
                        decode(item.getString("question")),
                        decode(item.getString("category")),
                        item.getString("difficulty"),
                        decode(item.getString("correct_answer")),
                        wrongAnswers));
            }

            if (parsed.isEmpty()) {
                showErrorDialog(getString(R.string.error_no_questions));
                return;
            }

            questions = parsed;
            records = new ArrayList<>();
            currentIndex = 0;
            score = 0;
            answered = false;
            selectedIndex = -1;

            Log.d(TAG, "Parsed " + parsed.size() + " questions");
            Toast.makeText(this, getString(R.string.toast_questions_loaded, parsed.size()),
                    Toast.LENGTH_SHORT).show();
            showQuestion();
        } catch (JSONException e) {
            Log.e(TAG, "JSON parsing failed", e);
            showErrorDialog(getString(R.string.error_parse));
        }
    }

    private void handleError(VolleyError error) {
        Log.e(TAG, "Volley request failed", error);
        int message;
        if (error instanceof NoConnectionError) {
            message = R.string.error_no_internet;
        } else if (error instanceof TimeoutError) {
            message = R.string.error_timeout;
        } else if (error instanceof ServerError) {
            message = R.string.error_server;
        } else {
            message = R.string.error_network;
        }
        showErrorDialog(getString(message));
    }

    /** The API sends HTML entities such as &quot; and &#039; so turn them back into text. */
    private static String decode(String html) {
        return Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY).toString();
    }

    // ---------------------------------------------------------------------
    // Quiz flow
    // ---------------------------------------------------------------------

    /** Pushes the current question into the Data Binding variables. */
    private void showQuestion() {
        binding.setLoading(false);
        Question question = questions.get(currentIndex);

        binding.setQuestion(question);
        binding.setQuestionNumber(currentIndex + 1);
        binding.setTotalQuestions(questions.size());
        binding.setScore(score);
        binding.progressQuiz.setMax(questions.size());
        binding.progressQuiz.setProgressCompat(currentIndex + 1, true);

        if (answered) {
            applyAnsweredState();
        } else {
            resetOptions();
        }
        binding.executePendingBindings();
        Log.d(TAG, "Showing question " + (currentIndex + 1) + " of " + questions.size());
    }

    /** Event listener for the four answer buttons. */
    private void onOptionSelected(int choice) {
        if (answered || questions.isEmpty()) {
            return;
        }
        answered = true;
        selectedIndex = choice;

        Question question = questions.get(currentIndex);
        String chosen = question.getOptions().get(choice);
        boolean correct = question.isCorrect(chosen);
        if (correct) {
            score++;
        }
        records.add(new AnswerRecord(currentIndex + 1, question.getText(), chosen,
                question.getCorrectAnswer(), correct));
        binding.setScore(score);
        Log.d(TAG, "Q" + (currentIndex + 1) + " answered: " + chosen
                + " -> " + (correct ? "correct" : "wrong") + ", score " + score);

        applyAnsweredState();

        // Popup feedback
        String message = correct
                ? getString(R.string.snackbar_correct)
                : getString(R.string.snackbar_wrong, question.getCorrectAnswer());
        Snackbar.make(binding.getRoot(), message, Snackbar.LENGTH_SHORT)
                .setBackgroundTint(ContextCompat.getColor(this, correct ? R.color.correct : R.color.wrong))
                .setTextColor(ContextCompat.getColor(this, R.color.white))
                .show();
    }

    /** Colours the buttons and swaps the ImageView to show whether the answer was right. */
    private void applyAnsweredState() {
        Question question = questions.get(currentIndex);
        String chosen = question.getOptions().get(selectedIndex);
        boolean correct = question.isCorrect(chosen);

        for (int i = 0; i < optionButtons.length; i++) {
            String option = question.getOptions().get(i);
            if (question.isCorrect(option)) {
                styleOption(optionButtons[i], R.color.correct, R.color.white);
            } else if (i == selectedIndex) {
                styleOption(optionButtons[i], R.color.wrong, R.color.white);
            } else {
                styleOption(optionButtons[i], R.color.option_bg, R.color.text_secondary);
            }
        }

        binding.imgFeedback.setImageResource(correct ? R.drawable.ic_correct : R.drawable.ic_wrong);
        binding.tvFeedback.setText(correct
                ? getString(R.string.feedback_correct)
                : getString(R.string.feedback_wrong, question.getCorrectAnswer()));
        binding.tvFeedback.setTextColor(ContextCompat.getColor(this,
                correct ? R.color.correct : R.color.wrong));

        boolean lastQuestion = currentIndex == questions.size() - 1;
        binding.btnNext.setText(lastQuestion ? R.string.btn_finish : R.string.btn_next);
        binding.btnNext.setVisibility(View.VISIBLE);
    }

    private void resetOptions() {
        for (MaterialButton button : optionButtons) {
            styleOption(button, R.color.option_bg, R.color.text_primary);
        }
        binding.imgFeedback.setImageResource(R.drawable.ic_feedback_idle);
        binding.tvFeedback.setText(R.string.quiz_prompt);
        binding.tvFeedback.setTextColor(ContextCompat.getColor(this, R.color.text_secondary));
        binding.btnNext.setVisibility(View.INVISIBLE);
    }

    private void styleOption(MaterialButton button, int backgroundColor, int textColor) {
        button.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(this, backgroundColor)));
        button.setTextColor(ContextCompat.getColor(this, textColor));
    }

    private void goToNextQuestion() {
        if (currentIndex < questions.size() - 1) {
            currentIndex++;
            answered = false;
            selectedIndex = -1;
            showQuestion();
            binding.scrollQuiz.smoothScrollTo(0, 0);
        } else {
            openResults();
        }
    }

    /** Sends the student details, score and answer list to ResultActivity in a Bundle. */
    private void openResults() {
        Bundle bundle = new Bundle(studentBundle);
        bundle.putInt(AppKeys.KEY_SCORE, score);
        bundle.putInt(AppKeys.KEY_TOTAL, questions.size());
        bundle.putSerializable(AppKeys.KEY_RECORDS, records);

        Intent intent = new Intent(QuizActivity.this, ResultActivity.class);
        intent.putExtras(bundle);
        Log.d(TAG, "Quiz finished with score " + score + "/" + questions.size()
                + ", opening ResultActivity");
        startActivity(intent);
        finish();
    }

    @SuppressWarnings("unchecked")
    private boolean restoreState(Bundle state) {
        ArrayList<Question> savedQuestions =
                BundleCompat.getSerializable(state, STATE_QUESTIONS, ArrayList.class);
        if (savedQuestions == null || savedQuestions.isEmpty()) {
            return false;
        }
        ArrayList<AnswerRecord> savedRecords =
                BundleCompat.getSerializable(state, STATE_RECORDS, ArrayList.class);

        questions = savedQuestions;
        records = savedRecords != null ? savedRecords : new ArrayList<>();
        currentIndex = state.getInt(STATE_INDEX, 0);
        score = state.getInt(STATE_SCORE, 0);
        answered = state.getBoolean(STATE_ANSWERED, false);
        selectedIndex = state.getInt(STATE_SELECTED, -1);
        if (answered && selectedIndex < 0) {
            answered = false;
        }
        return true;
    }

    // ---------------------------------------------------------------------
    // Popup dialogs
    // ---------------------------------------------------------------------

    private void showErrorDialog(String message) {
        binding.setLoading(false);
        if (isFinishing() || isDestroyed()) {
            return;
        }
        activeDialog = new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.dialog_error_title)
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton(R.string.action_retry, (dialog, which) -> fetchQuestions())
                .setNegativeButton(R.string.action_exit, (dialog, which) -> finish())
                .show();
    }

    private void showQuitDialog() {
        activeDialog = new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.dialog_quit_title)
                .setMessage(R.string.dialog_quit_message)
                .setPositiveButton(R.string.action_quit, (dialog, which) -> finish())
                .setNegativeButton(R.string.action_continue, null)
                .show();
    }
}
