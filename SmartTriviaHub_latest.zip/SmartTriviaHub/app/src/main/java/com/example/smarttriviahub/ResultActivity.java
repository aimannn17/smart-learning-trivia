package com.example.smarttriviahub;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.os.BundleCompat;
import androidx.databinding.DataBindingUtil;

import com.example.smarttriviahub.databinding.ActivityResultBinding;
import com.example.smarttriviahub.databinding.ItemResultBinding;

import java.util.ArrayList;

/**
 * Activity 3: Performance Analytics & Breakdown.
 * Works out the percentage and grade, lists every answer in a scrollable view
 * and lets the student restart the assessment.
 */
public class ResultActivity extends AppCompatActivity {

    private static final String TAG = "ResultActivity";

    private ActivityResultBinding binding;
    private Bundle resultBundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate() called: result screen created");

        binding = DataBindingUtil.setContentView(this, R.layout.activity_result);

        resultBundle = getIntent().getExtras();
        if (resultBundle == null) {
            Log.d(TAG, "No result data received, closing");
            finish();
            return;
        }

        int score = resultBundle.getInt(AppKeys.KEY_SCORE, 0);
        int total = resultBundle.getInt(AppKeys.KEY_TOTAL, 0);
        int percentage = calculatePercentage(score, total);

        binding.setStudentName(resultBundle.getString(AppKeys.KEY_NAME));
        binding.setStudentId(resultBundle.getString(AppKeys.KEY_STUDENT_ID));
        binding.setProgramme(resultBundle.getString(AppKeys.KEY_PROGRAMME));
        binding.setScore(score);
        binding.setTotal(total);
        binding.setPercentage(percentage);
        binding.setGrade(getString(gradeFor(percentage)));
        binding.setGradeMessage(getString(messageFor(percentage)));
        binding.progressScore.setProgressCompat(percentage, true);

        showBreakdown();

        binding.btnRetake.setOnClickListener(v -> retakeAssessment());
        binding.btnNewStudent.setOnClickListener(v -> restartAsNewStudent());

        Log.d(TAG, "Score " + score + "/" + total + " = " + percentage + "%");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "onStart() called: result screen is visible");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume() called: user can review results");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause() called: result screen losing focus");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop() called: result screen no longer visible");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG, "onRestart() called: returning to result screen");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy() called: result screen destroyed");
    }

    /** Percentage = correct / total x 100, rounded to the nearest whole number. */
    static int calculatePercentage(int score, int total) {
        if (total <= 0) {
            return 0;
        }
        return Math.round(score * 100f / total);
    }

    static int gradeFor(int percentage) {
        if (percentage >= 80) return R.string.grade_a;
        if (percentage >= 60) return R.string.grade_b;
        if (percentage >= 40) return R.string.grade_c;
        return R.string.grade_d;
    }

    static int messageFor(int percentage) {
        if (percentage >= 80) return R.string.message_a;
        if (percentage >= 60) return R.string.message_b;
        if (percentage >= 40) return R.string.message_c;
        return R.string.message_d;
    }

    /** Adds one data-bound row per question to the scrollable breakdown list. */
    @SuppressWarnings("unchecked")
    private void showBreakdown() {
        ArrayList<AnswerRecord> records =
                BundleCompat.getSerializable(resultBundle, AppKeys.KEY_RECORDS, ArrayList.class);
        if (records == null) {
            return;
        }
        LayoutInflater inflater = getLayoutInflater();
        for (AnswerRecord record : records) {
            ItemResultBinding row = ItemResultBinding.inflate(inflater, binding.layoutBreakdown, true);
            row.setRecord(record);
            row.executePendingBindings();
        }
    }

    /** Same student, new set of questions. */
    private void retakeAssessment() {
        Bundle studentBundle = new Bundle();
        studentBundle.putString(AppKeys.KEY_NAME, resultBundle.getString(AppKeys.KEY_NAME));
        studentBundle.putString(AppKeys.KEY_STUDENT_ID, resultBundle.getString(AppKeys.KEY_STUDENT_ID));
        studentBundle.putString(AppKeys.KEY_EMAIL, resultBundle.getString(AppKeys.KEY_EMAIL));
        studentBundle.putString(AppKeys.KEY_PROGRAMME, resultBundle.getString(AppKeys.KEY_PROGRAMME));

        Intent intent = new Intent(ResultActivity.this, QuizActivity.class);
        intent.putExtras(studentBundle);
        Log.d(TAG, "Retaking assessment");
        startActivity(intent);
        finish();
    }

    /** Back to the registration screen with an empty form. */
    private void restartAsNewStudent() {
        Intent intent = new Intent(ResultActivity.this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        Log.d(TAG, "Restarting as a new student");
        startActivity(intent);
        finish();
    }
}
