package com.example.smarttriviahub;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/** Checks the percentage and grade logic used by ResultActivity. */
public class ScoreCalculationTest {

    @Test
    public void percentageIsRoundedCorrectly() {
        assertEquals(100, ResultActivity.calculatePercentage(10, 10));
        assertEquals(70, ResultActivity.calculatePercentage(7, 10));
        assertEquals(0, ResultActivity.calculatePercentage(0, 10));
        assertEquals(67, ResultActivity.calculatePercentage(2, 3));
    }

    @Test
    public void zeroTotalDoesNotCrash() {
        assertEquals(0, ResultActivity.calculatePercentage(0, 0));
    }

    @Test
    public void gradeBoundaries() {
        assertEquals(R.string.grade_a, ResultActivity.gradeFor(80));
        assertEquals(R.string.grade_b, ResultActivity.gradeFor(79));
        assertEquals(R.string.grade_b, ResultActivity.gradeFor(60));
        assertEquals(R.string.grade_c, ResultActivity.gradeFor(40));
        assertEquals(R.string.grade_d, ResultActivity.gradeFor(39));
    }
}
